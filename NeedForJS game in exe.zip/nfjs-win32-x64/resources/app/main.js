const url = require('url').format({
    protocol: 'file',
    slashes: true,
    pathname: require('path').join(__dirname, 'index.html')
});

const {app, BrowserWindow} = require('electron');

let win;   // state of app

function createWindow() {
    win = new BrowserWindow({
        width: 500,
        height: 850
    });

    win.loadURL(url);

    win.on('closed', function(){
        win = null;
    });
    
}

app.on('ready', createWindow);

app.on('window-all-closed', function(){         //for Mac and Linux
    app.quit();
});
